package Bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Conexiones {
	
	Connection conn;
	Statement sT;
	ResultSet rS;
	int irS;
	
	public Conexiones(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection ("jdbc:mysql://tshjava.ctamjypccx1v.eu-west-1.rds.amazonaws.com:3306/alex","root", "rootroot");
			sT=conn.createStatement();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList consultar(){
		ArrayList<String> resultado=new ArrayList();
		
		try {
			rS=sT.executeQuery("select * from emple");
			while(rS.next()){
				resultado.add(rS.getString(1));
				resultado.add(rS.getString(2));
				resultado.add(rS.getString(3));
				resultado.add("*");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return resultado;
	}
	
	public void a�adir(String nombre,String apellidos,int salario){
		try {
			irS=sT.executeUpdate("insert into emple values('"+nombre+"','"+apellidos+"',"+salario+")");
			System.out.println("insert into emple values('"+nombre+"','"+apellidos+"',"+salario+")");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
